import SwiftUI
import CoreLocation
import PhotosUI
import Vision

struct Trip: Codable, Identifiable {
    var id = UUID(); var start: Date; var end: Date; var km: Double; var weather: String; var estimatedStart: Double?; var estimatedEnd: Double?
}
struct Ledger: Codable { var trips: [Trip] = []; var reading: Double?; var readingAt: Int = 0 }
struct Session: Codable { var start: Date; var km: Double = 0; var weather = "Non disponible"; var estimatedStart: Double? }
@MainActor final class Tracker: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var ledger = Ledger(); @Published var session: Session?; @Published var status = "Prêt"; @Published var weather = "Non disponible"
    private let gps = CLLocationManager(); private var last: CLLocation?; private var requestedWeather = false
    private let storage = UserDefaults.standard
    var estimate: Double? { ledger.reading.map { $0 + ledger.trips.dropFirst(ledger.readingAt).reduce(0) {$0+$1.km} } }
    var due: Bool { ledger.reading == nil || ledger.trips.count - ledger.readingAt >= 10 }
    override init() { super.init(); if let data = storage.data(forKey:"ledger"), let x = try? JSONDecoder().decode(Ledger.self,from:data) { ledger=x }; gps.delegate=self; gps.desiredAccuracy=kCLLocationAccuracyBest; gps.distanceFilter=5; gps.activityType = .automotiveNavigation; gps.pausesLocationUpdatesAutomatically=false; if let data=storage.data(forKey:"session"), let x=try? JSONDecoder().decode(Session.self,from:data) { session=x; status="Trajet interrompu : reprenez ou terminez" } }
    func save() { storage.set(try? JSONEncoder().encode(ledger),forKey:"ledger"); storage.set(try? JSONEncoder().encode(session),forKey:"session") }
    func start() { if gps.authorizationStatus == .notDetermined { gps.requestWhenInUseAuthorization(); status="Autorisez le GPS puis appuyez sur START"; return }; guard gps.authorizationStatus == .authorizedWhenInUse || gps.authorizationStatus == .authorizedAlways else { status="Activez la localisation dans Réglages"; return }; guard gps.accuracyAuthorization == .fullAccuracy else { status="Activez la localisation précise"; return }; if session == nil { session=Session(start:Date(),estimatedStart:estimate); requestedWeather=false }; last=nil; gps.allowsBackgroundLocationUpdates=true; gps.showsBackgroundLocationIndicator=true; gps.startUpdatingLocation(); status="GPS actif"; save() }
    func stop() { guard let s=session else {return}; gps.stopUpdatingLocation(); last=nil; ledger.trips.append(Trip(start:s.start,end:Date(),km:s.km,weather:s.weather,estimatedStart:s.estimatedStart,estimatedEnd:s.estimatedStart.map{$0+s.km})); session=nil; status="Trajet enregistré"; save() }
    func calibrate(_ value: Double) { guard session == nil, value.isFinite, value>=0 else {return}; ledger.reading=value; ledger.readingAt=ledger.trips.count; save() }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) { status="GPS indisponible : distance potentiellement incomplète" }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) { guard session != nil else {return}; for p in locations { guard p.horizontalAccuracy >= 0, p.horizontalAccuracy <= 30, abs(p.timestamp.timeIntervalSinceNow)<30, p.timestamp >= session!.start else {continue}; if let a=last { let dt=p.timestamp.timeIntervalSince(a.timestamp); let d=p.distance(from:a); if dt<=0 {continue}; if dt<60 && d/dt<65 && d>=max(5,min(15,p.horizontalAccuracy/2)) {session!.km += d/1000} }; last=p; if !requestedWeather { requestedWeather=true; let id=session!.start; Task { let result=await Self.fetchWeather(p.coordinate); if session?.start == id {session?.weather=result; save()} else if let i=ledger.trips.firstIndex(where:{$0.start==id}) {ledger.trips[i].weather=result; save()} } } }; save() }
    static func fetchWeather(_ c: CLLocationCoordinate2D) async -> String { let url=URL(string:"https://api.open-meteo.com/v1/forecast?latitude=\(c.latitude)&longitude=\(c.longitude)&current=temperature_2m,weather_code,is_day")!; do { let (data,_)=try await URLSession.shared.data(from:url); let json=try JSONSerialization.jsonObject(with:data) as? [String:Any]; guard let current=json?["current"] as? [String:Any], let temp=current["temperature_2m"] as? Double, let code=current["weather_code"] as? Int else {return "Non disponible"}; let label: String; switch code {case 0: label="Dégagé"; case 1...3: label="Nuageux"; case 45...48: label="Brouillard"; case 51...67,80...82: label="Pluie"; case 71...77,85...86: label="Neige"; case 95...99: label="Orage"; default: label="Code météo \(code)"}; return "\(label), \(temp) °C, \((current["is_day"] as? Int)==1 ? "jour":"nuit")" } catch {return "Non disponible"} }
}
@main struct MyRoadbookApp: App {
    @StateObject var tracker = Tracker()
    var body: some Scene {
        WindowGroup { ContentView(t: tracker).preferredColorScheme(.dark) }
    }
}

private let night = Color(red: 0.035, green: 0.067, blue: 0.12)
private let panel = Color(red: 0.075, green: 0.125, blue: 0.20)
private let accent = Color(red: 0.24, green: 0.72, blue: 1)
private let muted = Color(red: 0.60, green: 0.69, blue: 0.80)
private let activeGreen = Color(red: 0.13, green: 0.80, blue: 0.60)
private let activeRed = Color(red: 1, green: 0.34, blue: 0.40)

private struct PremiumCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content.frame(maxWidth: .infinity, alignment: .leading).padding(18)
            .background(panel, in: RoundedRectangle(cornerRadius: 23))
            .overlay(RoundedRectangle(cornerRadius: 23).strokeBorder(Color.white.opacity(0.08), lineWidth: 1))
    }
}

struct ContentView: View {
    @ObservedObject var t: Tracker
    @State private var photo: PhotosPickerItem?
    @State private var reading = ""
    @State private var recognized = ""
    @State private var tab = 0
    private var total: Double { t.ledger.trips.reduce(0) { $0 + $1.km } }
    private var remaining: Int { max(0, 10 - (t.ledger.trips.count - t.ledger.readingAt)) }
    private var interrupted: Bool { t.status.hasPrefix("Trajet interrompu") }
    private var recording: Bool { t.session != nil && !interrupted }
    private var actionColor: Color { recording ? activeRed : activeGreen }
    private var validReading: Bool {
        guard let n = Double(reading.replacingOccurrences(of: ",", with: ".")) else { return false }
        return n.isFinite && n >= 0
    }

    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { screen { home }.navigationBarTitleDisplayMode(.inline) }
                .tabItem { Label("Accueil", systemImage: "house.fill") }.tag(0)
            NavigationStack { screen { history }.navigationTitle("Trajets").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { ShareLink(item: csv) { Image(systemName: "square.and.arrow.up") }.accessibilityLabel("Exporter les trajets") } }
            }.tabItem { Label("Trajets", systemImage: "list.bullet.rectangle") }.tag(1)
            NavigationStack { screen { meter }.navigationTitle("Compteur").navigationBarTitleDisplayMode(.inline) }
                .tabItem { Label("Compteur", systemImage: "gauge.with.dots.needle.50percent") }.tag(2)
        }
        .tint(accent)
    }

    private func screen<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        ScrollView { VStack(spacing: 16) { content() }.padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 24).frame(maxWidth: 600) }
            .frame(maxWidth: .infinity)
            .background(night.ignoresSafeArea())
            .toolbarBackground(night, for: .navigationBar, .tabBar)
            .toolbarBackground(.visible, for: .navigationBar, .tabBar)
            .scrollDismissesKeyboard(.interactively)
    }

    private var home: some View {
        VStack(spacing: 16) {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Fiesta").font(.system(size: 38, weight: .heavy, design: .rounded).italic()).foregroundStyle(.white)
                    Text("MON CARNET DE CONDUITE").font(.system(size: 10, weight: .semibold)).tracking(2).foregroundStyle(muted)
                }
                Spacer()
                Image(systemName: "car.side.fill").font(.system(size: 28, weight: .medium)).foregroundStyle(accent)
                    .frame(width: 62, height: 56).background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 18))
                    .accessibilityHidden(true)
            }
            PremiumCard {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("DISTANCE D’APPRENTISSAGE").font(.caption2.weight(.semibold)).tracking(1).foregroundStyle(muted)
                        Spacer()
                        Image(systemName: "road.lanes").foregroundStyle(accent)
                    }
                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        Text(total, format: .number.precision(.fractionLength(1))).font(.system(size: 43, weight: .bold, design: .rounded)).monospacedDigit().minimumScaleFactor(0.5)
                        Text("km").font(.title3.weight(.medium)).foregroundStyle(muted)
                    }
                    ProgressView(value: min(1500, total), total: 1500).tint(accent)
                    HStack {
                        Text("Objectif : 1 500 km")
                        Spacer()
                        Text("\(t.ledger.trips.count) trajets")
                    }.font(.caption).foregroundStyle(muted)
                }
            }
            PremiumCard {
                VStack(spacing: 14) {
                    HStack(spacing: 7) {
                        Circle().fill(recording ? activeGreen : muted).frame(width: 7, height: 7)
                        Text(recording ? "TRAJET EN COURS" : interrupted ? "TRAJET INTERROMPU" : "PRÊT À PARTIR")
                            .font(.caption2.weight(.semibold)).tracking(1.3).foregroundStyle(recording ? activeGreen : muted)
                    }
                    Button {
                        if t.session != nil && !interrupted { t.stop() } else { t.start() }
                    } label: {
                        ZStack {
                            Circle().strokeBorder(actionColor.opacity(0.18), lineWidth: 2).frame(width: 157, height: 157)
                            Circle().fill(LinearGradient(colors: [actionColor, actionColor.opacity(0.73)], startPoint: .topLeading, endPoint: .bottomTrailing))
                                .frame(width: 139, height: 139).shadow(color: actionColor.opacity(0.22), radius: 13, x: 0, y: 4)
                            VStack(spacing: 6) {
                                Image(systemName: recording ? "stop.fill" : "play.fill").font(.system(size: 27, weight: .semibold))
                                Text(recording ? "STOP" : interrupted ? "REPRENDRE" : "START").font(.system(size: interrupted ? 15 : 24, weight: .heavy, design: .rounded))
                            }.foregroundStyle(night)
                        }.frame(width: 163, height: 163)
                    }.buttonStyle(.plain)
                    if interrupted { Button("Terminer le trajet") { t.stop() }.font(.subheadline.weight(.semibold)) }
                    HStack(alignment: .firstTextBaseline, spacing: 5) {
                        Text(t.session?.km ?? 0, format: .number.precision(.fractionLength(1))).font(.system(size: 36, weight: .bold, design: .rounded)).monospacedDigit()
                        Text("km").foregroundStyle(muted)
                    }
                    Text(t.status).font(.caption).foregroundStyle(muted).multilineTextAlignment(.center)
                }.frame(maxWidth: .infinity)
            }
            PremiumCard {
                HStack(spacing: 13) {
                    Image(systemName: weatherIcon(t.session?.weather ?? "")).font(.title2).foregroundStyle(accent).frame(width: 42, height: 42).background(accent.opacity(0.10), in: RoundedRectangle(cornerRadius: 13))
                    VStack(alignment: .leading, spacing: 4) {
                        Text("MÉTÉO AU DÉPART").font(.caption2.weight(.semibold)).tracking(1).foregroundStyle(muted)
                        Text(t.session?.weather ?? "Disponible au démarrage").font(.subheadline.weight(.medium))
                    }
                    Spacer(minLength: 0)
                }
            }
            Button { tab = 2 } label: {
                PremiumCard {
                    HStack(spacing: 13) {
                        Image(systemName: "gauge.with.dots.needle.50percent").font(.title2).foregroundStyle(t.due ? Color.orange : accent)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Relevé du compteur").font(.subheadline.weight(.semibold)).foregroundStyle(.white)
                            Text(t.due ? "Relevé nécessaire" : "Prochain relevé dans \(remaining) trajets").font(.caption).foregroundStyle(t.due ? Color.orange : muted)
                        }
                        Spacer()
                        Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(muted)
                    }
                }
            }.buttonStyle(.plain).disabled(t.session != nil)
        }
    }

    private var history: some View {
        VStack(spacing: 12) {
            PremiumCard {
                VStack(alignment: .leading, spacing: 7) {
                    Text("MON HISTORIQUE").font(.caption2.weight(.semibold)).tracking(1.5).foregroundStyle(muted)
                    Text("\(t.ledger.trips.count) trajets").font(.system(size: 30, weight: .bold, design: .rounded))
                    Text("\(total, specifier: "%.1f") km enregistrés").foregroundStyle(accent).font(.subheadline.weight(.medium))
                }
            }
            if t.ledger.trips.isEmpty {
                PremiumCard {
                    VStack(spacing: 12) {
                        Image(systemName: "road.lanes").font(.system(size: 34)).foregroundStyle(accent)
                        Text("Aucun trajet pour le moment").font(.headline)
                        Text("Tes prochaines séances apparaîtront ici.").font(.subheadline).foregroundStyle(muted).multilineTextAlignment(.center)
                        Button("Retour à l’accueil") { tab = 0 }.font(.subheadline.weight(.semibold))
                    }.frame(maxWidth: .infinity).padding(.vertical, 18)
                }
            }
            ForEach(t.ledger.trips.reversed()) { trip in
                PremiumCard {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: "car.fill").foregroundStyle(accent).frame(width: 40, height: 40).background(accent.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                            VStack(alignment: .leading, spacing: 5) {
                                Text(trip.start.formatted(date: .abbreviated, time: .shortened)).font(.subheadline.weight(.semibold))
                                Text("\(Int(trip.end.timeIntervalSince(trip.start)/60)) min").font(.caption).foregroundStyle(muted)
                            }
                            Spacer(minLength: 4)
                            Text("\(trip.km, specifier: "%.2f") km").font(.system(.title3, design: .rounded, weight: .bold)).monospacedDigit().foregroundStyle(accent).minimumScaleFactor(0.7)
                        }
                        Divider().overlay(Color.white.opacity(0.04))
                        Label(trip.weather, systemImage: weatherIcon(trip.weather)).font(.caption).foregroundStyle(muted)
                        if let a = trip.estimatedStart, let b = trip.estimatedEnd {
                            Label("Compteur estimé : \(a, specifier: "%.1f") → \(b, specifier: "%.1f")", systemImage: "gauge.with.dots.needle.50percent").font(.caption).foregroundStyle(muted)
                        }
                    }
                }
            }
        }
    }

    private var meter: some View {
        VStack(spacing: 16) {
            PremiumCard {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("COMPTEUR ESTIMÉ").font(.caption2.weight(.semibold)).tracking(1).foregroundStyle(muted)
                        Spacer()
                        Image(systemName: "gauge.with.dots.needle.50percent").foregroundStyle(accent)
                    }
                    if let e = t.estimate {
                        Text("\(e, specifier: "%.1f") km").font(.system(size: 34, weight: .bold, design: .rounded)).monospacedDigit().minimumScaleFactor(0.6)
                    } else { Text("À renseigner").font(.title2.bold()) }
                    ProgressView(value: Double(min(10, max(0, t.ledger.trips.count - t.ledger.readingAt))), total: 10).tint(t.due ? .orange : accent)
                    Text("\(t.ledger.trips.count - t.ledger.readingAt)/10 trajets depuis le relevé").font(.caption).foregroundStyle(muted)
                }
            }
            PremiumCard {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Nouveau relevé").font(.title3.bold())
                    Text("Photographie le tableau de bord, puis sélectionne la photo pour lire le kilométrage.").font(.subheadline).foregroundStyle(muted)
                    PhotosPicker(selection: $photo, matching: .images) {
                        Label("Choisir une photo", systemImage: "photo.on.rectangle.angled").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity).padding(15).background(accent.opacity(0.10), in: RoundedRectangle(cornerRadius: 14))
                    }.buttonStyle(.plain).foregroundStyle(accent)
                    if !recognized.isEmpty { Text(recognized).font(.caption).foregroundStyle(muted) }
                    TextField("Kilométrage réel à confirmer", text: $reading).keyboardType(.decimalPad).padding(15).background(night, in: RoundedRectangle(cornerRadius: 13))
                    Button {
                        if let n = Double(reading.replacingOccurrences(of: ",", with: ".")), n.isFinite, n >= 0 { t.calibrate(n); reading = ""; recognized = "" }
                    } label: {
                        Text("Confirmer le relevé").font(.subheadline.weight(.bold)).frame(maxWidth: .infinity).padding(15).foregroundStyle(night).background(accent, in: RoundedRectangle(cornerRadius: 14))
                    }.buttonStyle(.plain).disabled(t.session != nil || !validReading).opacity(t.session != nil || !validReading ? 0.4 : 1)
                }
            }
            PremiumCard {
                Label("Le relevé corrige uniquement l’estimation future du compteur. Les distances GPS déjà enregistrées restent inchangées.", systemImage: "info.circle").font(.footnote).foregroundStyle(muted)
            }
        }
        .onChange(of: photo) { _, item in
            Task {
                guard let data = try? await item?.loadTransferable(type: Data.self) else { return }
                let request = VNRecognizeTextRequest(); request.recognitionLevel = .accurate
                do {
                    try VNImageRequestHandler(data: data).perform([request])
                    let lines = request.results?.compactMap { $0.topCandidates(1).first?.string } ?? []
                    recognized = lines.joined(separator: " · ")
                    if let match = lines.compactMap({ $0.replacingOccurrences(of: " ", with: "").range(of: "^[0-9]{3,8}$", options: .regularExpression) != nil ? $0.replacingOccurrences(of: " ", with: "") : nil }).first { reading = match }
                } catch { recognized = "Lecture impossible : encodez le compteur." }
            }
        }
    }

    private func weatherIcon(_ weather: String) -> String {
        if weather.contains("Orage") { return "cloud.bolt.rain.fill" }
        if weather.contains("Pluie") { return "cloud.rain.fill" }
        if weather.contains("Neige") { return "cloud.snow.fill" }
        if weather.contains("Brouillard") { return "cloud.fog.fill" }
        if weather.contains("Nuageux") { return "cloud.fill" }
        if weather.contains("Dégagé") { return weather.contains("nuit") ? "moon.stars.fill" : "sun.max.fill" }
        return "cloud.sun.fill"
    }

    var csv: String { (["Départ;Arrivée;Distance GPS (km);Météo;Compteur départ estimé;Compteur arrivée estimé"]+t.ledger.trips.map {x in [x.start.ISO8601Format(),x.end.ISO8601Format(),String(x.km),x.weather,x.estimatedStart.map{String($0)} ?? "",x.estimatedEnd.map{String($0)} ?? ""].joined(separator:";")}).joined(separator:"\n") }
}
